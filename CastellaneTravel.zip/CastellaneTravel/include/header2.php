<html>
    <head>
        <title>Header 1</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            div.header{
                border: aqua solid thick;
                background-color: red;
                position: absolute;
                top: 0;
                height: 100px;
                width: 98%;
                margin: auto;
            }
            
            div.footer{
                background-color: blue;
                border: aqua solid thick;
                position: absolute;
                bottom: 0;
                height: 100px;
                width: 98%;
            }
        </style>
    </head>
    <body>
        <div class="header"></div>