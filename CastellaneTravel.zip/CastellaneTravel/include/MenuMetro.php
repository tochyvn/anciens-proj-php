
    <div class="w8">
        <div class="w8-fx-slice">
            <a href="article.php">
                <img class="img-responsive" src="img/about-bg.jpg" alt="">
            </a>
        </div>
    </div>
    <div class="w8 big">
        <div class="w8-fx-slice">
            <img class="img-responsive" src="img/about-bg.jpg" alt="">
        </div>
    </div>
    <div class="w8 little">
        <div class="w8-fx-slice">
            <img class="img-responsive" src="img/about-bg.jpg" alt="">
        </div>
    </div>
    

    <div class="w8 big">
        <div class="w8-fx-slice">
            <img class="img-responsive" src="img/about-bg.jpg" alt="">
        </div>
    </div>
    <div class="w8 mini">
        <div class="w8-fx-slice">
            <img class="img-responsive" src="img/about-bg.jpg" alt="">
        </div>
    </div>
    <div class="w8 little">
        <div class="w8-fx-slice">
            <img class="img-responsive" src="img/about-bg.jpg" alt="">
        </div>
    </div>
    <div class="w8 normal">
        <div class="w8-fx-slice">
            <img class="img-responsive" src="img/about-bg.jpg" alt="">
        </div>
    </div>
    <div class="w8">
        <div class="w8-fx-slice">
            <img class="img-responsive" src="img/about-bg.jpg" alt="">
        </div>
    </div>
    <div class="w8 little">
        <div class="w8-fx-slice">
            <img class="img-responsive" src="img/about-bg.jpg" alt="">
        </div>
    </div>
    <div class="w8 little">
        <div class="w8-fx-slice">
            <img class="img-responsive" src="img/about-bg.jpg" alt="">
        </div>
    </div>
    <div class="w8 little">
        <div class="w8-fx-slice">
            <img class="img-responsive" src="img/about-bg.jpg" alt="">
        </div>
    </div>