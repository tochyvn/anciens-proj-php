<!-- Main Content -->
        <div class="container">
            <div class="row">
                <div class="col-lg-1  hidden-sm hidden-xs">
                <!--<nav class='menu'>
                        <input checked='checked' class='menu-toggler' id='menu-toggler' type='checkbox'>
                        <label for='menu-toggler'></label>
                        <ul>
                          <li class='menu-item'>
                            <a class='fa fa-facebook' href='https://www.facebook.com/' target='_blank'></a>
                          </li>
                          <li class='menu-item'>
                            <a class='fa fa-google' href='https://www.google.com/' target='_blank'></a>
                          </li>
                          <li class='menu-item'>
                            <a class='fa fa-dribbble' href='https://dribbble.com/' target='_blank'></a>
                          </li>
                          <li class='menu-item'>
                            <a class='fa fa-codepen' href='http://codepen.io/' target='_blank'></a>
                          </li>
                          <li class='menu-item'>
                            <a class='fa fa-linkedin' href='https://www.linkedin.com/' target='_blank'></a>
                          </li>
                          <li class='menu-item'>
                            <a class='fa fa-github' href='https://github.com/' target='_blank'></a>
                          </li>
                        </ul>
                    </nav> -->
                    <div id="menuSide">
                        <div class="menu"id="menuSide">
                            <div class='bar'></div>
                            <div class='bar'></div>
                            <div class='bar'></div>  
                        </div>
                        <ul>
                            <li><a>Home</a></li>
                            <li><a>About</a></li>
                            <li><a>Pricing</a></li>
                            <li><a>Contact Us</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-9 col-lg-offset-2 col-md-10 col-md-offset-1">
                    <div class="post-heading">
                        <h2 class="section-heading">The Final Frontier</h2>
                        <p>There can be no thought of finishing for ‘aiming for the stars.’ Both figuratively and literally, it is a task to occupy the generations. And no matter how much progress one makes, there is always the thrill of just beginning.</p>
                        <p>There can be no thought of finishing for ‘aiming for the stars.’ Both figuratively and literally, it is a task to occupy the generations. And no matter how much progress one makes, there is always the thrill of just beginning.</p>
                        <blockquote>The dreams of yesterday are the hopes of today and the reality of tomorrow. Science has not yet mastered prophecy. We predict too much for the next year and yet far too little for the next ten.</blockquote>
                        <p>Spaceflights cannot be stopped. This is not the work of any one man or even a group of men. It is a historical process which mankind is carrying out in accordance with the natural laws of human development.</p>
                        <a href="#">
                            <img class="img-responsive" src="img/post-sample-image.jpg" alt="">
                        </a>
                    </div>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-lg-8 col-lg-offset-4 col-md-10 col-md-offset-2 hidden-sm hidden-xs">
                   <?php include'include/MenuMetro.php' ?>
                </div>
            </div>
        </div>

        <hr>