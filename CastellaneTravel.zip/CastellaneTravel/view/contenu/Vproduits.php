<div class="container produits">
    
    
    
   <?php if (isset($_SESSION['email'])) { echo $_SESSION['email'].' est bien connecté<br/><br/>'; }?> 
    COUCOU VOICI MES PRODUITS
    
</div>

