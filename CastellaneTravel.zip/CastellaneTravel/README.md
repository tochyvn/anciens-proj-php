# [Start Bootstrap](http://getbootstrap.com/)

## Getting Started

Project's website of the PopCorn Travelers' team. Institut G4 Marseille
## Copyright and License

Copyright 2015 Institut G4. Code released under the [Apache 2.0] license.